
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


   public class Departments extends javax.swing.JFrame {
  
    public Departments() {
        initComponents();
        display();
    }
    
    public void reset(){
        
        DeptID.setText("");
        DeptName.setText("");
        DeptIntake.setText("");
        DeptFees.setText("");
        
    }
    
    
    public void display(){
        
        try{
        
            Connection SC1 = DriverManager.getConnection( "jdbc:sqlserver://localhost\\DESKTOP-2SK42F8:1433;databaseName=UniversityManagementSystem;encrypt=true;trustServerCertificate=true;","User","123");
            Statement stmt = SC1.createStatement();
            String query = "SELECT * FROM Departments";
            ResultSet rs = stmt.executeQuery(query);
            DefaultTableModel tblModel = (DefaultTableModel)Departments_table.getModel();
            tblModel.setRowCount(0);
            
            while(rs.next()){
                
                String dID = rs.getString(1);
                String dName = rs.getString(2);
                String dIntake = rs.getString(3);
                String dFees = rs.getString(4);
                
                String[] rows = {dID, dName, dIntake, dFees};
                
                tblModel.addRow(rows);
                
            }
    
        } catch (SQLException e) {
            
            JOptionPane.showMessageDialog(null, e);
        }
    } 
       

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        DeptIntakeLb = new javax.swing.JLabel();
        DeptName = new javax.swing.JTextField();
        DeptFees = new javax.swing.JTextField();
        DeptFeesLb = new javax.swing.JLabel();
        DeptIntake = new javax.swing.JTextField();
        DeptNameLb = new javax.swing.JLabel();
        SaveBtn = new javax.swing.JButton();
        EditBtn = new javax.swing.JButton();
        DeleteBtn = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Departments_table = new javax.swing.JTable();
        DeptNameLb1 = new javax.swing.JLabel();
        DeptID = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        Departments = new javax.swing.JButton();
        Fees = new javax.swing.JButton();
        Salary = new javax.swing.JButton();
        Faculty = new javax.swing.JButton();
        Students = new javax.swing.JButton();
        Home = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        Courses = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        logout = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel14.setFont(new java.awt.Font("Baskerville Old Face", 1, 30)); // NOI18N
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("LSCE DEPARTMENTS");

        jPanel2.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 31, Short.MAX_VALUE)
        );

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/University-of-london-logo_1.png"))); // NOI18N

        DeptIntakeLb.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        DeptIntakeLb.setText("Intake:");

        DeptName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeptNameActionPerformed(evt);
            }
        });

        DeptFees.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeptFeesActionPerformed(evt);
            }
        });

        DeptFeesLb.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        DeptFeesLb.setText("Fees (Semester):");

        DeptIntake.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeptIntakeActionPerformed(evt);
            }
        });

        DeptNameLb.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        DeptNameLb.setText("Department ID:");

        SaveBtn.setText("Save");
        SaveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveBtnActionPerformed(evt);
            }
        });

        EditBtn.setText("Update");
        EditBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditBtnActionPerformed(evt);
            }
        });

        DeleteBtn.setText("Delete");
        DeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteBtnActionPerformed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 102)));

        Departments_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "DeptID", "DeptName", "DeptIntake", "DeptFees"
            }
        ));
        Departments_table.setSelectionBackground(new java.awt.Color(255, 255, 255));
        Departments_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Departments_tableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Departments_table);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 776, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 338, Short.MAX_VALUE)
        );

        DeptNameLb1.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        DeptNameLb1.setText("Department Name:");

        DeptID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeptIDActionPerformed(evt);
            }
        });

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        jLabel37.setIcon(new javax.swing.ImageIcon(getClass().getResource("/HOME.png"))); // NOI18N
        jLabel37.setText("jLabel3");

        jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-schoolboy-at-a-desk-32.png"))); // NOI18N
        jLabel38.setText("jLabel6");

        jLabel39.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-student-center-30.png"))); // NOI18N
        jLabel39.setText("jLabel7");

        jLabel40.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-department-50.png"))); // NOI18N
        jLabel40.setText("jLabel10");

        jButton11.setBorder(null);
        jButton11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton11.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-pay-30.png"))); // NOI18N
        jLabel41.setText("jLabel9");

        jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-teacher-50.png"))); // NOI18N
        jLabel42.setText("jLabel8");

        jLabel43.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-cash-30.png"))); // NOI18N

        Departments.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Departments.setText("Departments");
        Departments.setBorderPainted(false);
        Departments.setContentAreaFilled(false);
        Departments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Departments.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DepartmentsHome4ActionPerformed(evt);
            }
        });

        Fees.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Fees.setText("Fees");
        Fees.setBorderPainted(false);
        Fees.setContentAreaFilled(false);
        Fees.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Fees.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FeesHome5ActionPerformed(evt);
            }
        });

        Salary.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Salary.setText("Salary");
        Salary.setBorderPainted(false);
        Salary.setContentAreaFilled(false);
        Salary.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Salary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalaryHome6ActionPerformed(evt);
            }
        });

        Faculty.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Faculty.setText("Faculty");
        Faculty.setBorderPainted(false);
        Faculty.setContentAreaFilled(false);
        Faculty.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Faculty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FacultyHome7ActionPerformed(evt);
            }
        });

        Students.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Students.setText("Students");
        Students.setBorderPainted(false);
        Students.setContentAreaFilled(false);
        Students.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Students.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        Students.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StudentsHome2ActionPerformed(evt);
            }
        });

        Home.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Home.setText("Home");
        Home.setBorderPainted(false);
        Home.setContentAreaFilled(false);
        Home.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Home.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        Home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HomeHome2ActionPerformed(evt);
            }
        });

        jPanel5.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        Courses.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Courses.setText("Courses");
        Courses.setBorderPainted(false);
        Courses.setContentAreaFilled(false);
        Courses.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Courses.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CoursesHome2ActionPerformed(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-logout-rounded-down-50.png"))); // NOI18N
        jLabel5.setText("jLabel5");

        logout.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        logout.setForeground(new java.awt.Color(204, 0, 0));
        logout.setText("Logout");
        logout.setBorderPainted(false);
        logout.setContentAreaFilled(false);
        logout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutHome2ActionPerformed(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 9, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton11)
                .addGap(891, 891, 891))
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(logout))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Courses)
                                    .addComponent(Students)))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Home))))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel42, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel43, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Faculty)
                            .addComponent(Fees)
                            .addComponent(Salary)
                            .addComponent(Departments))))
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(751, 751, 751))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel37)
                                    .addComponent(Home, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Students, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Courses, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(25, 25, 25)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Departments, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel41)
                                    .addComponent(Fees, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Faculty, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(20, 20, 20)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel43)
                                    .addComponent(Salary, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(logout, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(29, 29, 29)
                .addComponent(jButton11)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jLabel2)
                .addGap(30, 30, 30)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 381, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(3, 3, 3)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addComponent(SaveBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(EditBtn)
                        .addGap(149, 149, 149)
                        .addComponent(DeleteBtn)
                        .addGap(150, 150, 150))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(5, 5, 5)
                                        .addComponent(DeptNameLb, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(DeptID, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(68, 68, 68)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(DeptNameLb1, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(DeptName, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(64, 64, 64)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(DeptIntakeLb, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                                    .addComponent(DeptIntake))
                                .addGap(55, 55, 55)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(DeptFeesLb, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(DeptFees, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(12, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(DeptIntakeLb, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(DeptFeesLb, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(DeptNameLb1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(DeptNameLb, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(DeptName, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(DeptIntake, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(DeptFees, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(DeptID, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SaveBtn)
                            .addComponent(EditBtn)
                            .addComponent(DeleteBtn))
                        .addGap(18, 18, 18)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 646, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void DeptNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeptNameActionPerformed
       
    }//GEN-LAST:event_DeptNameActionPerformed

    private void DeptIntakeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeptIntakeActionPerformed
        
    }//GEN-LAST:event_DeptIntakeActionPerformed

    private void DeptFeesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeptFeesActionPerformed
        
    }//GEN-LAST:event_DeptFeesActionPerformed
 
    private void DeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteBtnActionPerformed
         
        int ID = Integer.parseInt(DeptID.getText().toString());
        
        String query = "Delete From Departments where DeptID = " + ID + " ";
        
        try{
            
            Connection SC1 = DriverManager.getConnection( "jdbc:sqlserver://localhost\\DESKTOP-2SK42F8:1433;databaseName=UniversityManagementSystem;encrypt=true;trustServerCertificate=true;","User","123");
            Statement stmt = SC1.createStatement();
            stmt.execute(query);
             JOptionPane.showMessageDialog(null, "Data has been Deleted."+ " "+
             JOptionPane.OK_OPTION + JOptionPane.INFORMATION_MESSAGE);
             display();
             
        } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
        
    }//GEN-LAST:event_DeleteBtnActionPerformed

    private void EditBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditBtnActionPerformed
       
        if (DeptName.getText().equals("") || DeptIntake.getText().equals("")
                || DeptFees.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Missing Information.", "Error",
                    JOptionPane.OK_OPTION+ JOptionPane.ERROR_MESSAGE);
        } else {
            
            int ID = Integer.parseInt(DeptID.getText().toString());
            String Name = DeptName.getText().toString();
            int Intake = Integer.parseInt(DeptIntake.getText().toString());
            int Fees = Integer.parseInt(DeptFees.getText().toString());
            
            String query = "Update Departments set DeptName = '" + Name + "', DeptIntake = " + Intake + " ,"
                    + " DeptFees = " + Fees + " where DeptID = " + ID + " ";
            
            try {
               
            Connection SC1 = DriverManager.getConnection( "jdbc:sqlserver://localhost\\DESKTOP-2SK42F8:1433;databaseName=UniversityManagementSystem;encrypt=true;trustServerCertificate=true;","User","123");
            Statement stmt = SC1.createStatement();
            stmt.execute(query);
             JOptionPane.showMessageDialog(null, "Department Information Updated."+ " "+
             JOptionPane.OK_OPTION + JOptionPane.INFORMATION_MESSAGE);
             display();
             reset();
                
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }//GEN-LAST:event_EditBtnActionPerformed

    private void SaveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveBtnActionPerformed
         
        if (DeptName.getText().equals("") || DeptIntake.getText().equals("")
                || DeptFees.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Missing Information." + "Error");
        
        } else {
            
            int ID = Integer.parseInt(DeptID.getText().toString());
            String Name = DeptName.getText().toString();
            int Intake = Integer.parseInt(DeptIntake.getText().toString());
            int Fees = Integer.parseInt(DeptFees.getText().toString());
            
            String query = "INSERT INTO Departments Values ("+ID+",'"+Name+"',"+Intake+","+Fees+") ";            
            
            try {

            Connection SC1 = DriverManager.getConnection( "jdbc:sqlserver://localhost\\DESKTOP-2SK42F8:1433;databaseName=UniversityManagementSystem;encrypt=true;trustServerCertificate=true;","User","123");
            Statement stmt = SC1.createStatement();
            stmt.execute(query);
             JOptionPane.showMessageDialog(null, "Department Added."+ " "+
             JOptionPane.OK_OPTION + JOptionPane.INFORMATION_MESSAGE);
             display();
             reset();
             
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }//GEN-LAST:event_SaveBtnActionPerformed

    private void DeptIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeptIDActionPerformed

    }//GEN-LAST:event_DeptIDActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed

    }//GEN-LAST:event_jButton11ActionPerformed

    private void DepartmentsHome4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DepartmentsHome4ActionPerformed

        Departments d1 = new Departments();
        dispose();
        d1.setVisible(true);
    }//GEN-LAST:event_DepartmentsHome4ActionPerformed

    private void FeesHome5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FeesHome5ActionPerformed

        Fees f1 = new Fees();
        dispose();
        f1.setVisible(true);
    }//GEN-LAST:event_FeesHome5ActionPerformed

    private void SalaryHome6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalaryHome6ActionPerformed

        Salaries sal1 = new Salaries();
        dispose();
        sal1.setVisible(true);
    }//GEN-LAST:event_SalaryHome6ActionPerformed

    private void FacultyHome7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FacultyHome7ActionPerformed

        Faculty fac1 = new Faculty();
        dispose();
        fac1.setVisible(true);
    }//GEN-LAST:event_FacultyHome7ActionPerformed

    private void StudentsHome2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StudentsHome2ActionPerformed

        Student s1 = new Student();
        dispose();
        s1.setVisible(true);
    }//GEN-LAST:event_StudentsHome2ActionPerformed

    private void HomeHome2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HomeHome2ActionPerformed

        Home h1 = new Home();
        dispose();
        h1.setVisible(true);

    }//GEN-LAST:event_HomeHome2ActionPerformed

    private void CoursesHome2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CoursesHome2ActionPerformed

        Course c1 = new Course();
        dispose();
        c1.setVisible(true);

    }//GEN-LAST:event_CoursesHome2ActionPerformed

    private void logoutHome2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutHome2ActionPerformed

        Login log = new Login();
        dispose();
        log.setVisible(true);

    }//GEN-LAST:event_logoutHome2ActionPerformed

    private void Departments_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Departments_tableMouseClicked

        DefaultTableModel tblModel = (DefaultTableModel)Departments_table.getModel();
        String ID = tblModel.getValueAt(Departments_table.getSelectedRow(),0).toString();
        String Name = tblModel.getValueAt(Departments_table.getSelectedRow(),1).toString();
        String Intake = tblModel.getValueAt(Departments_table.getSelectedRow(),2).toString();
        String Fees = tblModel.getValueAt(Departments_table.getSelectedRow(),3).toString();

        DeptID.setText(ID);
        DeptName.setText(Name);
        DeptIntake.setText(Intake);
        DeptFees.setText(Fees);

    }//GEN-LAST:event_Departments_tableMouseClicked

 
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Courses;
    private javax.swing.JButton DeleteBtn;
    private javax.swing.JButton Departments;
    private javax.swing.JTable Departments_table;
    private javax.swing.JTextField DeptFees;
    private javax.swing.JLabel DeptFeesLb;
    private javax.swing.JTextField DeptID;
    private javax.swing.JTextField DeptIntake;
    private javax.swing.JLabel DeptIntakeLb;
    private javax.swing.JTextField DeptName;
    private javax.swing.JLabel DeptNameLb;
    private javax.swing.JLabel DeptNameLb1;
    private javax.swing.JButton EditBtn;
    private javax.swing.JButton Faculty;
    private javax.swing.JButton Fees;
    private javax.swing.JButton Home;
    private javax.swing.JButton Salary;
    private javax.swing.JButton SaveBtn;
    private javax.swing.JButton Students;
    private javax.swing.JButton jButton11;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logout;
    // End of variables declaration//GEN-END:variables
}
