public class Program {
    
    public static void main(String[] args) {
        
        //the main entry point of project
        
        LoadScreen LS = new LoadScreen();
        LS.setVisible(true);
        
        try{
            Thread.sleep(5500);
            Login l1 = new Login();
            LS.dispose();
            l1.show();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
}
